package cn.bdqn.pojo;

import java.io.Serializable;
/**
 * Ա����
 * @author ����ΰ
 * create by 2019-9-29 16:56:23
 *
 */
public class Employees implements Serializable {
	private Integer employeesId;//Ա��id
	private String userName;//�û���
	private String password;//����
	private String name;//��ʵ����
	private String sex;//�Ա�
	private String phone;//�绰
	private Integer employeestype;//Ա������(1.Ա����2.�쵼��3.��̨����)
	private Integer	departmentId;//����id
	private Double integral;//����
	private Integer test;//����id
	private String email;//����
	private String registTime;//ע��ʱ��
	private String introduce;//���
	

	public String getIntroduce() {
		return introduce;
	}
	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}
	public String getRegistTime() {
		return registTime;
	}
	public void setRegistTime(String registTime) {
		this.registTime = registTime;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getEmployeesId() {
		return employeesId;
	}
	public void setEmployeesId(Integer employeesId) {
		this.employeesId = employeesId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Integer getEmployeestype() {
		return employeestype;
	}
	public void setEmployeestype(Integer employeestype) {
		this.employeestype = employeestype;
	}
	public Integer getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	public Double getIntegral() {
		return integral;
	}
	public void setIntegral(Double integral) {
		this.integral = integral;
	}
	public Integer getTest() {
		return test;
	}
	public void setTest(Integer test) {
		this.test = test;
	}
	
}
