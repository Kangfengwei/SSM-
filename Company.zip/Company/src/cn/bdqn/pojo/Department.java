package cn.bdqn.pojo;

import java.io.Serializable;
/**
 * ���ű�
 * @author ����ΰ
 * create by 2019-9-29 16:56:23
 *
 */
public class Department implements Serializable {
		private Integer departmentId;//Ա��id
		private String departmentName;//��������
		public Integer getDepartmentId() {
			return departmentId;
		}
		public void setDepartmentId(Integer departmentId) {
			this.departmentId = departmentId;
		}
		public String getDepartmentName() {
			return departmentName;
		}
		public void setDepartmentName(String departmentName) {
			this.departmentName = departmentName;
		}
		
}
