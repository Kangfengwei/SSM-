package cn.bdqn.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.bdqn.pojo.Employees;
import cn.bdqn.pojo.Question;
import cn.bdqn.service.EmployeesService;
import cn.bdqn.service.QuestionService;

@Controller
@RequestMapping("/ques")
public class QuestionController {
	@Resource(name="questionService")
	private QuestionService questionService;
	@Resource(name="employeesService")
	private EmployeesService employeesService;
	
	@RequestMapping("/selectAll")
	public String SelectAll(HttpServletRequest request){
		List<Question> qList= questionService.selectAllQuestion();
		request.setAttribute("qList",qList);
		return "question/question";
	}
	
	@RequestMapping("/update/{questionId}/{name}")
	public String updateQues(@PathVariable("questionId")Integer questionId,@PathVariable("name")String name,HttpServletRequest request){
		Question ques=questionService.selectById(questionId);
		Employees ems=employeesService.selectByName(name);
		request.setAttribute("ques", ques);
		request.setAttribute("name", name);
		request.setAttribute("ems", ems);
		return "question/updateQues";
	}
	@RequestMapping("/upQues")
	public String upQues(@RequestParam("questionName")String questionName,@RequestParam("questionTime")String questionTime,@RequestParam("questionId")Integer questionId){
		int res=questionService.updateById(questionName, questionTime, questionId);
		return "redirect:/ques/selectAll";
	}
	@ResponseBody
	@RequestMapping("/delQues")
	public Integer delQues(@RequestParam("questionId")Integer questionId){
		int res=0;
		res=questionService.delById(questionId);
		return res;
	}
	
}
