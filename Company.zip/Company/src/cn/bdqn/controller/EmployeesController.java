package cn.bdqn.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.bdqn.pojo.Employees;
import cn.bdqn.service.EmployeesService;

import com.alibaba.fastjson.JSON;

@Controller
@RequestMapping("/emp")
public class EmployeesController {
	@Resource(name = "employeesService")
	private EmployeesService employeesService;

	@RequestMapping("/add")
	public String add() {
		return "user/addUser";
	}

	@ResponseBody
	// 添加用户
	@RequestMapping("/addUser")
	public Integer addUser(@RequestParam("userName") String userName,
			@RequestParam("password") String password,
			@RequestParam("name") String name,
			@RequestParam("phone") String phone,
			@RequestParam("employeestype") Integer employeestype,
			@RequestParam("sex") String sex,
			@RequestParam("email") String email,
			@RequestParam("introduce") String introduce) {
		int res = employeesService.addUser(userName, password, name, sex,
				phone, employeestype, email, introduce);
		return res;
	}

	@ResponseBody
	// 删除用户
	@RequestMapping("/delUser/{id}")
	public Integer delUser(@PathVariable("id") Integer id) {
		int res = employeesService.delUser(id);
		return res;
	}

	@RequestMapping("/indexs")
	public String indexs(HttpSession session) {
		session.removeAttribute("active");
		session.setAttribute("active", "user");
		return "indexs";
	}

	// 登录
	@RequestMapping("/login")
	public String login(@RequestParam("userName") String userName,
			@RequestParam("password") String password, HttpSession session) {
		Employees emp = employeesService.login(userName, password);
		session.setAttribute("emp", emp);
		if (emp != null) {
			return "indexs";
		}

		return "redirect:../index.jsp";
	}

	// 注销
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("emp");
		return "redirect:../index.jsp";
	}

	@RequestMapping("/selectByInfo")
	public String selectByInfo(HttpServletRequest request,
			@RequestParam("employeesId") Integer employeesId,
			@RequestParam("userName") String userName,
			@RequestParam("email") String email,
			@RequestParam("employeestype") Integer employeestype) {
		List<Employees> empList = employeesService.selectByInfo(employeesId,
				userName, email, employeestype);
		request.setAttribute("userList", empList);
		return "user/userAdmin";
	}

	/**
	 * BootStrap测试 2019-11-2
	 * 
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/table")
	public String table(HttpServletRequest request) {
		List<Employees> userList = new ArrayList<Employees>();
		userList = employeesService.selectAll();
		request.setAttribute("userList", userList);
		return JSON.toJSONString(userList);
	}

	// 根据id查询信息
	@RequestMapping("/update/{employeesId}")
	public String update(@PathVariable("employeesId") Integer employeesId,
			HttpServletRequest request) {
		Employees ems = new Employees();
		ems = employeesService.selectEmployees(employeesId);
		request.removeAttribute("ems");
		request.setAttribute("ems", ems);
		return "user/updateUser";
	}

	// 跳修改密码页面
	@RequestMapping("/updatePassword")
	public String updateUserPassword() {
		return "user/updateUserPassword";
	}

	@ResponseBody
	@RequestMapping("/upPassword/{employeesId}")
	public Integer upPassword(@RequestParam("password") String password,
			@PathVariable("employeesId") Integer employeesId) {
		int res = employeesService.upPassword(password, employeesId);
		return res;
	}

	// 修改
	@RequestMapping("/upUser")
	public String upUser(@RequestParam("userName") String userName,
			@RequestParam("name") String name,
			@RequestParam("phone") String phone,
			@RequestParam("employeestype") Integer employeestype,
			@RequestParam("sex") String sex,
			@RequestParam("email") String email,
			@RequestParam("introduce") String introduce,
			@RequestParam("employeesId") Integer employeesId) {
		int res = employeesService.upUser(userName, name, sex, phone,
				employeestype, email, introduce, employeesId);
		if (res > 0) {
			// 重定向
			System.out.println("***********性别：" + sex);
			return "redirect:/emp/userAdmin";
		}
		return "/emp/update/" + employeesId;
	}

	@RequestMapping("/userAdmin")
	public String userAdmin(HttpServletRequest request) {
		List<Employees> userList = new ArrayList<Employees>();
		userList = employeesService.selectAll();
		request.setAttribute("userList", userList);
		return "user/userAdmin";
	}
}
