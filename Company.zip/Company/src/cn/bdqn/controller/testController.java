package cn.bdqn.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("test")
public class testController {
	@RequestMapping("tests")
	public String tests(HttpSession session){
		session.removeAttribute("active");
		session.setAttribute("active","test");
		return "test/tests";
	}
}
