package cn.bdqn.service.Impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.bdqn.dao.EmployeesDao;
import cn.bdqn.pojo.Employees;
import cn.bdqn.service.EmployeesService;
@Service("employeesService")
public class EmployeesServiceImpl implements EmployeesService{
	@Resource(name="employeesDao")
	private EmployeesDao employeesDao;
	@Override
	public Employees login(String userName, String password) {
		return employeesDao.login(userName, password);
	}
	@Override
	public List<Employees> selectAll() {
		return employeesDao.selectAll();
	}
	@Override
	public Employees selectEmployees(Integer employeesId) {
		return employeesDao.selectEmployees(employeesId);
	}
	@Override
	public int upUser(String userName, String name, String sex, String phone,
			Integer employeestype, String email, String introduce,
			Integer employeesId) {
		return employeesDao.upUser(userName, name, sex, phone, employeestype, email, introduce, employeesId);
	}
	@Override
	public int upPassword(String password, Integer employeesId) {
		return employeesDao.upPassword(password, employeesId);
	}
	@Override
	public int addUser(String userName, String password, String name,
			String sex, String phone, Integer employeestype, String email,String introduce) {
		return employeesDao.addUser(userName, password, name, sex, phone, employeestype, email, introduce);
	}
	@Override
	public int delUser(Integer id) {
		return employeesDao.delUser(id);
	}
	@Override
	public List<Employees> selectByInfo(Integer employeesId, String userName,
			String email, Integer employeestype) {
		return employeesDao.selectByInfo(employeesId, userName, email, employeestype);
	}
	@Override
	public Employees selectByName(String name) {
		return employeesDao.selectByName(name);
	}
}
