package cn.bdqn.service.Impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.bdqn.dao.QuestionDao;
import cn.bdqn.pojo.Employees;
import cn.bdqn.pojo.Question;
import cn.bdqn.service.QuestionService;
@Service("questionService")
public class QuestionServiceImpl implements QuestionService {
	@Resource(name="questionDao")
	private QuestionDao questionDao;
	@Override
	public List<Question> selectAllQuestion() {
		return questionDao.selectAllQuestion();
	}
	@Override
	public Question selectById(Integer questionId) {
		return questionDao.selectById(questionId);
	}
	@Override
	public int updateById(String questionName, String questionTime,
			Integer questionId) {
		return questionDao.updateById(questionName, questionTime, questionId);
	}
	@Override
	public int delById(Integer questionId) {
		return questionDao.delById(questionId);
	}
	


}
