function upPassword(id){
	var pass1=$("input[name=password1]").val();
	var pass2=$("input[name=password2]").val();
	if(pass1!=pass2){
		alert("两次密码输入不一致");
	}else{
	$.ajax({
		url:"/Company/emp/upPassword/"+id,
		data:"password="+pass1,
		type:"GET",
		dataType:"text",
		success:function(res){
			if(res>0){
				alert("修改成功！");
				location.href="/Company/index.jsp";
			}
		},
		error:function(){
			
		}
		
	});									
}}
function delUser(id){
	if(confirm('确定要删除么？')){
		$.ajax({
			url:"/Company/emp/delUser/"+id,
			type:"GET",
			dataType:"text",
			success:function(res){
				if(res>0){
					alert("删除成功！");
					location.href="/Company/emp/userAdmin";
				}
			},
			error:function(){
				alert("删除错误！");
			}
		});		
	}
}
function addUser(){
	var pass1=$("input[name=password1]").val();
	var pass2=$("input[name=password2]").val();
	var username=$("input[name=username]").val();
	var name=$("input[name=name]").val();
	var employeestype=$("#employeestype").val();
	var sex = $('input[name="sex"]:checked').val();
	var phone=$("input[name=phone]").val();
	var email=$("input[name=email]").val();
	var introduce=$("input[name=introduce]").val();
	if(username==""){
		alert("请选择用户名！");
	}else{
		if(name==""){
			alert("请选择真实姓名！");
		}else{
			if(employeestype==0){
		alert("请选择一个角色!");
	}else{
		if(phone.length!=11){
			alert("请输入正确的手机号!");
		}else{
			 if(pass1==""){
				alert("请输入密码！");
			}else{
				if(pass2==""){
					alert("请输入重复密码！");
				}else{
			if(pass1!=pass2){
				alert("两次密码输入不一致");
			}else{
				if(/^[a-zA-Z0-9_\-]{2,}@[a-zA-Z0-9_\-]{2,}(\.[a-zA-Z0-9_\-]+){1,2}$/.test(email)){
					$.ajax({
						url:"/Company/emp/addUser",
						data:"userName="+username+"&name="+name+"&employeestype="+employeestype+
						"&sex="+sex+"&phone="+phone+"&password="+pass1+"&introduce="+introduce+"&email="+email,
						type:"GET",
						dataType:"text",
						success:function(res){
							if(res>0){
								alert("添加成功！");
								location.href="/Company/emp/userAdmin";
							}
						},
						error:function(){
						}
					});							
				}else{
					alert("请输入正确的邮箱！");
				}//邮箱
					}//密码
		}
	}//角色
	}
		}
	}}}
			